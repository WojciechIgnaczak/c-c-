#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "function_types.h"
#include "function_min.h"
#include "function_inrange.h"

#define BUFFER_SIZE 32

int main(int argc, char ** argv) {
             //0  1  2  3  4  5  6
  int tab[] = {5, 1, 2, 7, 3, 4, 6};
  int len;
  char bufferMain[BUFFER_SIZE];

  if (argc == 1) {
    printf("Bad program call\n");
  } else if (argc == 2) {
    if (!strcmp(argv[1], "min")){
      struct argument * args[1];
      serializeIntToStringBuffer(7, bufferMain, BUFFER_SIZE);
      args[0] = argumentConstructor("size", INT, bufferMain);
      printMin(tab, args, 1);
      argumentDestructor(args[0]);
    }
  } else if (argc == 6) {
    if (!strcmp(argv[1], "inRange")){
      bool minInclude, maxInclude;
      int min, max;

      if (strcmp(argv[4], "T") && strcmp(argv[4], "F")) {
        printf("Bad program call\n");
        return EXIT_FAILURE;
      }
        
      if (strcmp(argv[5], "T") && strcmp(argv[5], "F")) {
        printf("Bad program call\n");
        return EXIT_FAILURE;
      }
      
      struct argument * args[5];
      char * buffer;
            
      // inRange min
      buffer = getBufferWithString(argv[2]);
      args[1] = argumentConstructor("min", INT, buffer);
      
      // inRange max
      buffer = getBufferWithString(argv[3]);
      args[2] = argumentConstructor("max", INT, buffer);
      
      // inRange minInclude
      buffer = getBufferWithString(argv[4]);
      args[3] = argumentConstructor("minInclude", BOOL, buffer);
      
      // inRange maxInclude
      buffer = getBufferWithString(argv[5]);
      args[4] = argumentConstructor("maxInclude", BOOL, buffer);
      
      // data tab size
      serializeIntToStringBuffer(7, bufferMain, BUFFER_SIZE);
      args[0] = argumentConstructor("size", INT, bufferMain);
      
      printInRange(tab, args, 5);
      
      argumentDestructor(args[0]);
      argumentDestructor(args[1]);
      argumentDestructor(args[2]);
      argumentDestructor(args[3]);
      argumentDestructor(args[4]);
    }
  }
  return EXIT_SUCCESS;
}

