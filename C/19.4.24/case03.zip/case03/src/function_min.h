#ifndef FUNCTION_MIN
#define FUNCTION_MIN

void printMin(int * tab, struct argument * args[], int size);

#endif
