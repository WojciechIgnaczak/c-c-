#ifndef FUNCTION_INRANGE
#define FUNCTION_INRANGE

void printInRange(int * tab, struct argument * args [], int size);

#endif
