#include <stdbool.h>

#ifndef FUNCTION_TYPES
#define FUNCTION_TYPES

enum ArgType {INT, BOOL};

struct argument {
  char * name;
  enum ArgType type;
  char * value;
};

struct argument * argumentConstructor(char * name, enum ArgType type, char * value);
void argumentDestructor(struct argument * arg);

char * getBufferWithString(char * s);
void serializeIntToStringBuffer(int i, char * buffer, size_t bufferLength);
char * serializeBool(bool b);

#endif
