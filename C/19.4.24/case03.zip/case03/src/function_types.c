#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "function_types.h"

char * getBufferWithString(char * s){
  int len;
  char * buffer;
  
  len = strlen(s);
  buffer = (char *)malloc(sizeof(char)*(len+1));
  
  if (buffer != NULL){
    strcpy(buffer, s);
  }
  
  return buffer;
}

void serializeIntToStringBuffer(int i, char * buffer, size_t bufferLength){
  snprintf(buffer, bufferLength, "%d", i);
}

char * serializeBool(bool b){
  char * s = (char *)malloc(sizeof(char)*(1+1));
  
  if (s == NULL){
    return NULL;
  }
  
  s[0] = b ? 'T' : 'F';
  
  return s;
}

struct argument * argumentConstructor(char * name, enum ArgType type, char * value){
  struct argument * p;
  
  p = (struct argument *)malloc(sizeof(struct argument) * 1);
  if (p != NULL){
    p -> name = getBufferWithString(name);
    p -> value = getBufferWithString(value);
    p -> type = type;
  }

  return p;
}

void argumentDestructor(struct argument * arg){
  free(arg -> name);
  free(arg -> value);
  free(arg);
}
